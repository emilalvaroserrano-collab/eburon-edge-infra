const CACHE='eburon-edge-v0.3.0';
const CORE=['/','/index.html','/translate.html','/settings.html','/manifest.webmanifest'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url); if(url.origin!==location.origin) return;
  if(url.pathname.startsWith('/v1/')||url.pathname.startsWith('/ws/')||url.pathname==='/health') return;
  event.respondWith(fetch(event.request,{cache:'no-store'}).then(async r=>{if(r.ok){const c=await caches.open(CACHE);c.put(event.request,r.clone());}return r;}).catch(async()=>{const hit=await caches.match(event.request);if(hit)return hit;if(event.request.mode==='navigate')return caches.match('/index.html');return new Response('Not found',{status:404});}));
});
